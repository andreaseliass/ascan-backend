const axios = require('axios');

var fim = 0;
async function execute(){
    await axios.post('http://localhost:3000/users', {
        "full_name": "Andrea Elias"
    })
   
   await axios.post('http://localhost:3000/subscriptions/create', {
       "user_id": 31
    })
   await axios.patch('http://localhost:3000/subscriptions/cancel', {
        "user_id": 31
    })
      
    await axios.patch('http://localhost:3000/subscriptions/restart', {
        "user_id": 31
    })
    fim = 1;
 }

 
 async function createforsameuser(){
    await axios.post('http://localhost:3000/subscriptions/create', {
        "user_id": 31
    })
 }

 async function cancelforsameuser(){
    await axios.patch('http://localhost:3000/subscriptions/cancel', {
        "user_id": 31
    })
}
async function restartforsameuser(){
    await axios.patch('http://localhost:3000/subscriptions/restart', {
    "user_id": 31
})
}



async function executeAllFunctions() {
    try {
      await execute();
      await createforsameuser();
      await cancelforsameuser();
      await restartforsameuser();
      console.log('Todas as funções foram executadas com sucesso em sequência');
    } catch (err) {
      console.error('Alguma das funções falhou', err);
    }
  }
  
  executeAllFunctions();




